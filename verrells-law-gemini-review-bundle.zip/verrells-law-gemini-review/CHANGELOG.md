# Changelog

## 2025-09-03
- Initial public release of **Gemini (Google AI) Review Archive** PDF and materials.
- Added press note, citation file, and license.
